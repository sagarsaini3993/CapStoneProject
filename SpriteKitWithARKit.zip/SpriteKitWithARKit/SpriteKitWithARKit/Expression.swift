//
//  Expression.swift
//  SpriteKitWithARKit
//
//  Created by Manpreet Kaur Gill on 2019-08-12.
//  Copyright © 2019 Manpreet Kaur Gill. All rights reserved.
//

import UIKit
import ARKit

class Expression: NSObject {
    
    func name() -> String {
        return ""
    }
    func isExpressing(from: ARFaceAnchor) -> Bool {
        // should return true when the ARFaceAnchor is performing the expression we want
        return false
    }
 
    func isDoingWrongExpression(from: ARFaceAnchor) -> Bool {
        // should return true when the ARFaceAnchor is performing the WRONG expression from what we want. for example, if the expression is "Blink Left", then this should return true if the user's right eyelid is also closed.
        return false
    }

}

class SmileExpression: Expression {
    override func name() -> String {
        return "Smile"
    }
    override func isExpressing(from: ARFaceAnchor) -> Bool {
        guard let smileLeft = from.blendShapes[.mouthSmileLeft], let smileRight = from.blendShapes[.mouthSmileRight] else {
            return false
        }
        
        // from testing: 0.5 is a lightish smile, and 0.9 is an exagerrated smile
        return smileLeft.floatValue > 0.5 && smileRight.floatValue > 0.5
    }
}

class EyeBlinkLeftExpression: Expression {
    override func name() -> String {
        return "Blink Right"
    }
    // note: "left" is your personal left
    override func isExpressing(from: ARFaceAnchor) -> Bool {
        guard let eyeBlinkLeft = from.blendShapes[.eyeBlinkLeft], let eyeBlinkRight = from.blendShapes[.eyeBlinkRight] else {
            return false
        }
        
        // from testing: at least 0.6 is closed eye lid
        return eyeBlinkLeft.doubleValue > 0.6 && eyeBlinkRight.doubleValue > 0.6
    }
}

class JawOpenExpression: Expression {
    override func name() -> String {
        return "Open Wide"
    }
    override func isExpressing(from: ARFaceAnchor) -> Bool {
        guard let jawOpen = from.blendShapes[.jawOpen] else {
            return false
        }
        
        // from testing: 0.4 is casual open (aka casual breathing)
        return jawOpen.floatValue > 0.7
    }
}


