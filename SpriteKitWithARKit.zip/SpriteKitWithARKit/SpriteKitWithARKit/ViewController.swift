//
//  ViewController.swift
//  SpriteKitWithARKit
//
//  Created by Manpreet Kaur Gill on 2019-08-08.
//  Copyright © 2019 Manpreet Kaur Gill. All rights reserved.
//

import UIKit
import SpriteKit
import ARKit
import AVFoundation

class ViewController: UIViewController, ARSKViewDelegate, ARSessionDelegate {
    
    @IBOutlet var sceneView: ARSKView!
    var bombSound : AVAudioPlayer?
    var faceExpreesion: String = ""
   
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Set the view's delegate
        guard ARFaceTrackingConfiguration.isSupported else { fatalError() }
        sceneView.session.delegate = self
        
        // Show statistics such as fps and node count
        sceneView.showsFPS = true
        sceneView.showsNodeCount = true
        sceneView.showsPhysics = true
        
        // Load the SKScene from 'Scene.sks'
        if let scene = SKScene(fileNamed: "Scene") {
            scene.scaleMode = .aspectFill
            sceneView.presentScene(scene)
        }
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        // Create a session configuration
        let configuration = ARFaceTrackingConfiguration()
      //  configuration.planeDetection = [.horizontal, .vertical]
        // Run the view's session
        sceneView.session.run(configuration)
     
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        
        // Pause the view's session
        sceneView.session.pause()
    }
    
    
    
    func view(_ view: ARSKView, nodeFor anchor: ARAnchor) -> SKNode? {
        // Create and configure a node for the anchor added to the view's session.
        let labelNode = SKLabelNode(text: "")
        labelNode.horizontalAlignmentMode = .center
        labelNode.verticalAlignmentMode = .center
        return labelNode;
    }
    
    func session(_ session: ARSession, didFailWithError error: Error) {
        // Present an error message to the user
        
    }
    
    
    
    func sessionWasInterrupted(_ session: ARSession) {
        // Inform the user that the session has been interrupted, for example, by presenting an overlay
        
    }
    
    func sessionInterruptionEnded(_ session: ARSession) {
        // Reset tracking and/or remove existing anchors if consistent tracking is required
        
    }
    
    func session(_ session: ARSession, didUpdate anchors: [ARAnchor]) {
        // get the face anchor from the session
        // if the face anchor is null, then return (do nothing)
        guard let faceAnchor = anchors.first as? ARFaceAnchor else { return }
       // print(isExpressing(from: faceAnchor))
        
        if isExpressing(from: faceAnchor) == "smile" {
           // print("smiling")
            
            UserDefaults.standard.set("smile", forKey: "expression")
            //audio while shooting
            let path = Bundle.main.path(forResource: "gun_shot", ofType: "mp3")!
            do {
                bombSound = try AVAudioPlayer(contentsOf: URL(fileURLWithPath: path))
                bombSound?.play()
            } catch {
                print(error)
            }
        } else if isExpressing(from: faceAnchor) == "" {
           // print("Not Expression")
            UserDefaults.standard.set("noExp", forKey: "expression")
        } else if isExpressing(from: faceAnchor) == "jawOpen"{
           // print("jaw Open")
            UserDefaults.standard.set("jawOpen", forKey: "expression")
        }
        else if isExpressing(from: faceAnchor) == "notSmile"{
            //print("not simle")
            UserDefaults.standard.set("noSmile", forKey: "expression")
        }
    
    }
    
   
     func isExpressing(from: ARFaceAnchor) -> String {
        guard let smileLeft = from.blendShapes[.mouthSmileLeft], let smileRight = from.blendShapes[.mouthSmileRight], let jawOpen = from.blendShapes[.jawOpen]
    
            else {
                faceExpreesion = ""
            return faceExpreesion
        }
        // from testing: 0.5 is a lightish smile and 0.9 is an exagerrated smile
        if(smileLeft.floatValue > 0.5 && smileRight.floatValue > 0.5)
        {
           faceExpreesion = "smile"
             return faceExpreesion
        }
        
        if(jawOpen.floatValue > 0.7)
        {
            faceExpreesion = "jawOpen"
           return faceExpreesion
        }
        if(smileLeft.floatValue < 0.5 && smileRight.floatValue < 0.5)
        {
            faceExpreesion = "notSmile"
            return faceExpreesion
        }
        
        //return smileLeft.floatValue > 0.5 && smileRight.floatValue > 0.5 || jawOpen.floatValue > 0.7
        return faceExpreesion
    }

}
    


