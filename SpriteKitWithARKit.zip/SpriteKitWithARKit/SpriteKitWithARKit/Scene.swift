//
//  Scene.swift
//  SpriteKitWithARKit
//
//  Created by Manpreet Kaur Gill on 2019-08-08.
//  Copyright © 2019 Manpreet Kaur Gill. All rights reserved.
//

import SpriteKit
import ARKit
import GameplayKit

class Scene: SKScene, SKPhysicsContactDelegate{
    var enemy = SKSpriteNode(imageNamed: "enemy_128")
    var enemy2 = SKSpriteNode(imageNamed: "enemy_128")
    var enemy3 = SKSpriteNode(imageNamed: "enemy_128")
    var enemyArray:[SKNode] = []
   
    var coins:SKNode!
    var coinArray:[SKSpriteNode] = []
    
  
    
    var progressValue = 80
    var healthBar = SKSpriteNode()
    var healthBar1 = SKSpriteNode()
    var healthBar2 = SKSpriteNode()
    var healthBarArray:[SKNode] = []
    
    var Result:Bool = false
    var timer = SKLabelNode()
    var timerVal = 30.00
    var RandNumber:Int = 0
    var val : String = ""
    var oldValue : String = "old"
    var score: Int = 0
    
    
    override func didMove(to view: SKView) {
        
        print("Screen height \(frame.height)")
        print("Screen Width \(frame.width)")
        
        // Setup your scene here
        self.scene?.physicsWorld.contactDelegate = self
        
        self.enemyArray.append(enemy)
        self.enemyArray.append(enemy2)
        self.enemyArray.append(enemy3)
        
        self.healthBarArray.append(healthBar)
        self.healthBarArray.append(healthBar1)
        self.healthBarArray.append(healthBar2)
        
        //self.coins = self.childNode(withName: "coins")
        
        // create an array of coins
        for node in self.children {
            if (node.name == "coins") {
                self.coinArray.append(node as! SKSpriteNode)
            }
        }
        print("GAME SETUP: Finished adding coins to the array")
        
        setLabels()
        makeEnemies()
        updatePosition()
        
        
    }
    
    override func update(_ currentTime: TimeInterval) {
        
        // check if there are any coins on the screen
        let coinExists = scene?.childNode(withName: "coins")
        if (coinExists != nil) {
            // a coin exists
            print("Coin exists on scene!")
            // move the enemy to the position of the first coin in the array
            updatePosition()
        }
        else {
            // no more coins on screen, so do NOT move enemy
            print("Coin does not exist!")
            //display message on the screen you lose money
            let messageLabel = SKLabelNode(text: "You Lose Money")
            messageLabel.fontColor = UIColor.yellow
            messageLabel.fontSize = 60
            messageLabel.position.x = self.frame.size.width/2
            messageLabel.position.y = self.frame.size.height/2
            addChild(messageLabel)
        }
        
        //MARK:- Logic to kill enemis
        val = UserDefaults.standard.string(forKey: "expression")!
        if(val != oldValue)
        {
            
            print("value \(val)")
            // print("user def val is \(String(describing: val!))")
            
            if(val == "smile")
            {
                oldValue = val
                print("Scene side -----> " + val)
                
                if progressValue <= 0 && enemyArray.count != 0{
                    
                    print("Elements in array: \(enemyArray.count)")
                    print("--------")
                    
                    // 1. Enemy is dead, so remove it from the game
                    // --------------------
                    // removing emeny from scene
                    enemyArray[0].removeFromParent()
                    // remove enemy from array
                    enemyArray.remove(at: 0)
                    print("enemy array count \(enemyArray.count)")
                    
                    // 2. Remove the enemy's health bar
                    // --------------------
                    healthBarArray[0].removeFromParent()
                    healthBarArray.remove(at:0)
                    // reset the progress bar for the new progress bar at pos 0
                    print("Resetting health to 80")
                    progressValue = 80
                }
                else {
                    
                    if (healthBarArray.count > 0) {
                        print("Current health: \(progressValue)")
                        progressValue = progressValue - 20
                        
                        let currentHealthBar = healthBarArray[0] as! SKSpriteNode
                        currentHealthBar.size.width = CGFloat(progressValue);
                        //healthBarArray[0] = SKSpriteNode(color: SKColor.red, size: CGSize(width: progressValue, height: 10))
                    }
                   
                }
               if(enemyArray.count == 0)
                {
                    print("you win")
                    //display message you win
                    let messageLabel = SKLabelNode(text: "You Win")
                    messageLabel.fontColor = UIColor.yellow
                    messageLabel.fontSize = 60
                    messageLabel.position.x = self.frame.size.width/2
                    messageLabel.position.y = self.frame.size.height/2
                    addChild(messageLabel)
                }
                print("progress value \(progressValue)")
                
                // enemyArray[RandNumber].removeFromParent()
                
            }
            if(val == "noExp")
            {
                print("Scene side ------>" + val)
                oldValue = val
            }
            if(val == "jawOpen")
            {
                print("Scene side expr -----> " + val)
                oldValue = val
            }
            if(val == "noSmile")
            {
                print("Scene side expr ----->" + val)
                oldValue = val
            }
        }
        else{
            print("same expressions")
        }
        
    }
    
    //function to notify when two sprites touch
    func didBegin(_ contact: SKPhysicsContact) {
        let nodeA = contact.bodyA.node
        let nodeB = contact.bodyB.node
        
        if(nodeA?.name == "enemy" && nodeB?.name == "coins")
        {
            nodeB?.removeFromParent()
            // remove coin from array
            coinArray.remove(at: 0)
            Result = true
        }
        else if(nodeA?.name == "coins" && nodeB?.name == "enemy")
        {
            nodeA?.removeFromParent()
            // remove coin from array
            coinArray.remove(at: 0)
            Result = true
        }
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard let sceneView = self.view as? ARSKView else {
            return
        }
        
        // Create anchor using the camera's current position
        if let currentFrame = sceneView.session.currentFrame {
            
            // Create a transform with a translation of 0.2 meters in front of the camera
            var translation = matrix_identity_float4x4
            translation.columns.3.z = -0.2
            let transform = simd_mul(currentFrame.camera.transform, translation)
            
            // Add a new anchor to the session
            let anchor = ARAnchor(transform: transform)
            sceneView.session.add(anchor: anchor)
        }
    }
    func updatePosition()
    {
        for (i,enemy) in self.enemyArray.enumerated()
        {
            

            var a : CGFloat
            var b : CGFloat
            var distance : CGFloat
            var xn : CGFloat
            var yn : CGFloat
            
//            a = CGFloat(coins.position.x - enemy.position.x)
//            b = CGFloat(coins.position.y - enemy.position.y)


            a = CGFloat(coinArray[0].position.x - enemy.position.x)
            b = CGFloat(coinArray[0].position.y - enemy.position.y)

            distance = sqrt(a * a) + (b * b)
            
            //calculate the rate
            xn = a/distance
            yn = b/distance
            
            //move the enemy toward coin
            enemy.position.x = enemy.position.x + CGFloat(xn * 150)
            enemy.position.y = enemy.position.y + CGFloat(yn * 150)
            healthBarArray[i].position.x = enemyArray[i].position.x
            healthBarArray[i].position.y = enemyArray[i].position.y + 70
            
            
            //physics body
            let enemyBodyTexture = SKTexture(imageNamed: "enemy_128")
            enemy.physicsBody = SKPhysicsBody(texture: enemyBodyTexture,
                                              size: enemyBodyTexture.size())
            enemy.physicsBody?.isDynamic = true
            enemy.physicsBody?.allowsRotation = false
            enemy.physicsBody?.affectedByGravity = false
            enemy.physicsBody?.categoryBitMask = 2
            enemy.physicsBody?.collisionBitMask = 1
            enemy.physicsBody?.contactTestBitMask = 1
            enemy.name = "enemy"
            //print("Where is enemy ? \(enemy.position.x), \(enemy.position.y)")
        }
    }
    
    //make enemies
    func makeEnemies()
    {
        for (i,enemy) in self.enemyArray.enumerated()
        {
            
            let randX = CGFloat.random(in: 0 ..< self.size.width - 500)
            let randY = CGFloat.random(in: 0 ..< self.size.height - 200)
            
            enemyArray[i].position = CGPoint(x:randX , y:randY )
            
            healthBarArray[i] = SKSpriteNode(color: SKColor.red, size: CGSize(width: progressValue, height: 10))
            healthBarArray[i].position.x = enemyArray[i].position.x
            healthBarArray[i].position.y = enemyArray[i].position.y + 70
            self.addChild(healthBarArray[i])
            
            //            print("Where is enemy? \(randX), \(randY)")
            
            addChild(enemyArray[i])
            let enemyBodyTexture = SKTexture(imageNamed: "enemy_128")
            enemy.physicsBody = SKPhysicsBody(texture: enemyBodyTexture,
                                              size: enemyBodyTexture.size())
            enemy.physicsBody?.isDynamic = true
            enemy.physicsBody?.allowsRotation = false
            enemy.physicsBody?.affectedByGravity = false
            enemy.physicsBody?.categoryBitMask = 2
            enemy.physicsBody?.collisionBitMask = 1
            enemy.physicsBody?.contactTestBitMask = 1
            enemy.name = "enemy"
            //            print("Where is enemy ? \(randX), \(randY)")
        }
    }
    //set Labels
    func setLabels()
    {
        // label for Timer
        timer = SKLabelNode(fontNamed: "Chalkduster")
        timer.text = String(timerVal)
        timer.fontSize = 35
        timer.fontColor = SKColor.green
        timer.position = CGPoint(x: frame.width - 600, y: frame.height - 100)
        addChild(timer)
        
        // Label for Score
        let score = SKLabelNode(fontNamed: "Chalkduster")
        score.text = "100"
        score.fontSize = 35
        score.fontColor = SKColor.green
        score.position = CGPoint(x: frame.width - 150, y: frame.height - 100)
        addChild(score)
    }
    //move to next level
    func MoveToNextLevel()
    {
            if (Result == true)
            {
                let scene = SKScene(fileNamed:"Scene2")
                if (scene == nil) {
                    print("Error loading level")
                    return
                }
                else {
                    scene!.scaleMode = .aspectFill
                    view?.presentScene(scene!)
                }
                }
    }
}
